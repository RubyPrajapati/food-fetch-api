import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Search from './components/Search';

function App() {
  return (
  <>
   <Search />
  </>
  );
}

export default App;
